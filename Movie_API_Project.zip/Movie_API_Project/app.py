from argparse import Action
from multiprocessing.sharedctypes import Value
from unittest import result
from flask import Flask, render_template, request
from flask_mysqldb import MySQL
import yaml

from flask_paginate import Pagination, get_page_args

app = Flask(__name__)


db = yaml.safe_load(open('db.yaml'))

app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

mysql = MySQL(app)
@app.route('/search_by_movie_name', methods = ['GET','POST'])
def index():
    if request.method == 'POST':
        userDetails = request.form
        Movie_name = userDetails['Movie_name']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM movie_details WHERE Movie_Title = %s ", (Movie_name,))
        details = []
        for x in cur:
            details.append(x)
        return render_template('normal_table.html', result = details)
    
    return render_template('index.html')

@app.route('/by_keyword', methods = ['GET','POST'])
def index2():
    if request.method == 'POST':
        userDetails = request.form
        Movie_name = userDetails['Movie_name']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM movie_details WHERE lower(Movie_Title) Like %s ", ("%"+Movie_name.lower()+"%",))
        details = []
        for x in cur:
            details.append(x)
        return render_template('normal_table.html', result = details)
    
    return render_template('index.html')

users = list(range(200))

def get_users(offset=0,per_page=10):
    return users[offset:offset+per_page]

@app.route('/sort/by_name', methods = ['GET','POST'])
def sort_by_name():
    if request.method == 'POST':
        page,per_page,offset = get_page_args(page_parameter="page", per_page_parameter = "per_page")

        total = len(users)
        pagination_users = get_users(offset=offset,per_page=per_page)
        pagination = Pagination(page=page,per_page=per_page,total=total,css_framework='bootstrap4')

        cur = mysql.connection.cursor()
        cur.execute("SELECT Movie_Title, Movie_Description FROM movie_details ORDER BY Movie_Title")
        details = []
        for x in cur:
            details.append(x)
        return render_template('table.html', result = details,users=pagination_users,page=page,per_page=per_page,pagination=pagination)
    return render_template('sort_temp.html',Value = "Movie Name")

@app.route('/sort/by_rating', methods = ['GET','POST'])
def sort_by_rating():
    if request.method == 'POST':
        cur = mysql.connection.cursor()
        cur.execute("SELECT Movie_Title, Movie_Rating FROM movie_details ORDER BY  Movie_Rating")
        details = []
        for x in cur:
            details.append(x)
        return details
    return render_template('sort_temp.html',Value = "Rating ( ascending order)")

@app.route('/sort/by_release_date', methods = ['GET','POST'])
def sort_by_release_date():
    if request.method == 'POST':
        cur = mysql.connection.cursor()
        cur.execute("SELECT Movie_Title, Release_Date FROM movie_details ORDER BY  Release_Date DESC")
        details = []
        for x in cur:
            details.append(x)
        return details
    return render_template('sort_temp.html',Value = "Release Date")

@app.route('/sort/by_duration', methods = ['GET','POST'])
def sort_by_duration():
    if request.method == 'POST':
        cur = mysql.connection.cursor()
        cur.execute("SELECT Movie_Title, Movie_Duration FROM movie_details ORDER BY  Movie_Duration DESC")
        details = []
        for x in cur:
            details.append(x)
        return details

    return render_template('sort_temp.html',Value = "Duration")
if __name__ == "__main__":
    app.run(debug = True)